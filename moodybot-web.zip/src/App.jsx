import React, { useEffect, useState } from 'react';
import './App.css';
import io from 'socket.io-client';

function App() {
  const [currentMood, setCurrentMood] = useState('😊');
  const [temperature, setTemperature] = useState('N/A');
  const [co2Level, setCo2Level] = useState('N/A');

  const socket = io('http://localhost:3000');

  // 处理情绪变化
  const handleMoodChange = (mood) => {
    console.log('Mood changed to:', mood);
    setCurrentMood(mood);
    socket.emit('mood', mood);
  };

  // 处理移动指令
  const handleMove = (direction) => {
    console.log('Moving:', direction);
    socket.emit('move', direction); // 发送移动指令到后端
  };

  // 接收环境数据
  useEffect(() => {
    socket.on('environment', (data) => {
      setTemperature(data.temperature);
      setCo2Level(data.co2);
    });

    return () => {
      socket.off('environment');
    };
  }, []);

  // 启动游戏模式
  const startGameMode = () => {
    socket.emit('gameMode', true);
  };

  // 启动远程监控
  const startMonitoring = () => {
    socket.emit('startMonitoring', true);
  };

  // 组件卸载时断开连接
  useEffect(() => {
    return () => {
      socket.disconnect();
    };
  }, []);

  return (
    <div className="container">
      <h1>MoodyBot: Your Intelligent Desktop Companion</h1>
      <p>MoodyBot helps you stay energized and balanced.</p>

      {/* 情绪识别区块 */}
      <section className="card">
        <h2>😊 Emotional Recognition & LED Display</h2>
        <p>MoodyBot detects your emotions and reacts accordingly.</p>
        <div className="status-box">
          <h3>Current Mood: {currentMood}</h3>
          <button onClick={() => handleMoodChange('😊')}>Happy</button>
          <button onClick={() => handleMoodChange('😢')}>Sad</button>
          <button onClick={() => handleMoodChange('😴')}>Tired</button>
        </div>
      </section>

      {/* 环境监测区块 */}
      <section className="card">
        <h2>🌡️ Smart Environment Control</h2>
        <p>Monitors temperature & CO₂ levels.</p>
        <div>
          <p>Temperature: {temperature}°C</p>
          <p>CO₂ Level: {co2Level} ppm</p>
        </div>
        <button onClick={() => socket.emit('checkEnvironment')}>Check Environment</button>
      </section>

      {/* 移动控制区块 */}
      <section className="card">
        <h2>🚗 Movement Control</h2>
        <p>Control MoodyBot's movement.</p>
        <div className="movement-controls">
          <button onClick={() => handleMove('forward')}>↑ Forward</button>
          <div>
            <button onClick={() => handleMove('left')}>← Left</button>
            <button onClick={() => handleMove('right')}>→ Right</button>
          </div>
          <button onClick={() => handleMove('backward')}>↓ Backward</button>
        </div>
      </section>

      {/* 游戏模式区块 */}
      <section className="card">
        <h2>🎮 Fun & Playful Interaction</h2>
        <p>Activate game mode and let MoodyBot play.</p>
        <button onClick={startGameMode}>Start Game Mode</button>
      </section>

      {/* 远程监控区块 */}
      <section className="card">
        <h2>📹 Remote-Controlled Home Monitoring</h2>
        <p>Use MoodyBot as a security assistant.</p>
        <button onClick={startMonitoring}>Start Monitoring</button>
      </section>

      {/* 添加一个大空白区域，确保页面有足够高度 */}
      <div style={{ height: '500px' }}></div>
    </div>
  );
}

export default App;