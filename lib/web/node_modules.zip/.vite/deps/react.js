import {
  require_react
} from "./chunk-UXVLD57N.js";
export default require_react();
