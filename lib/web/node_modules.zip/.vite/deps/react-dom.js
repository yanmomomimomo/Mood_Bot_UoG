import {
  require_react_dom
} from "./chunk-BVXUDQN3.js";
import "./chunk-UXVLD57N.js";
export default require_react_dom();
