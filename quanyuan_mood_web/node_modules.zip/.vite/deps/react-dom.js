import {
  require_react_dom
} from "./chunk-WOFKNP6E.js";
import "./chunk-N57ZNOQ2.js";
import "./chunk-HKJ2B2AA.js";
export default require_react_dom();
