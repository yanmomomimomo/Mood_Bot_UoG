import {
  require_react
} from "./chunk-N57ZNOQ2.js";
import "./chunk-HKJ2B2AA.js";
export default require_react();
